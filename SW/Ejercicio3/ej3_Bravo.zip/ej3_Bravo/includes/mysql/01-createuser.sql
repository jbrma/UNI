CREATE USER 'ejercicio3'@'%' IDENTIFIED BY 'ejercicio3';
GRANT ALL PRIVILEGES ON `ejercicio3`.* TO 'ejercicio3'@'%';

CREATE USER 'ejercicio3'@'localhost' IDENTIFIED BY 'ejercicio3';
GRANT ALL PRIVILEGES ON `ejercicio3`.* TO 'ejercicio3'@'localhost';