package simulator.model;

import java.util.List;
import simulator.model.*;

public interface ForceLaws {
	public void apply(List<Body> bs);
}
